package com.teamandroids.triviagame.application.Database

class Question(
    var QType: String,
    var QDiff: Int,
    var Question: String,
    var Answer1a: String,
    var Answer2b: String,
    var Answer3c: String,
    var Answer4d: String,
    var correct: Int,
    var wasUsed: Boolean)