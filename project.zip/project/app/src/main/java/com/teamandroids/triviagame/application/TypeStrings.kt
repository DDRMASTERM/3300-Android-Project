package com.example.jacobgraves.myapplication

class TypeStrings {
    companion object {
        const val Science: String = "Science"
        const val Politics: String = "Politics"
        const val Sports: String = "Sports"
        const val History: String = "History"
        var Score: Int = 0
    }
//    public static Science: string = "Science"
//    public static Politics: string = "Politics"
//    public static Sports: string = "Sports"
//    public static score: int = 0

}